﻿HOW TO USE
==========
1. Put setup.bat and write_game.py in the same folder.
   (write_game.py = the text in 2_writer_code.txt, save it with the .py extension)
2. Double-click setup.bat
3. Wait 1-2 minutes. CatQuiz.exe appears in Downloads\CatQuiz and a shortcut on the Desktop.

FILES
=====
1_game_code.txt          the game (cat_quiz.py)
2_writer_code.txt        write_game.py - unpacks the game, icon and music
3_builder_bat_code.txt   setup.bat as text
4_libraries.txt          required libraries
setup.bat                the builder / installer (ready to run)
cat_icon.ico             the game icon
