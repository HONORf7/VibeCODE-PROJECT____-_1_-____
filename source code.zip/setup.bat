@echo off
title Cat Quiz Setup

set GAME_DIR=%USERPROFILE%\Downloads\CatQuiz
if not exist "%GAME_DIR%" mkdir "%GAME_DIR%"

echo Step 1: Finding Python...
set PYTHON=
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set PYTHON=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set PYTHON=%LOCALAPPDATA%\Programs\Python\Python310\python.exe
if exist "C:\Python312\python.exe" set PYTHON=C:\Python312\python.exe
if exist "C:\Python311\python.exe" set PYTHON=C:\Python311\python.exe

if "%PYTHON%"=="" (
    python --version >nul 2>&1
    if not errorlevel 1 for /f "tokens=*" %%i in ('where python 2^>nul') do if "%PYTHON%"=="" set PYTHON=%%i
)

if "%PYTHON%"=="" (
    echo Python not found. Downloading...
    curl -L -o "%TEMP%\pysetup.exe" "https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe"
    if errorlevel 1 ( echo ERROR: Cannot download Python. Check internet. & pause & exit /b 1 )
    "%TEMP%\pysetup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=0
    del "%TEMP%\pysetup.exe"
    set PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe
)

echo Python: %PYTHON%

echo Step 2: Checking VS Code...
if exist "%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe" (
    echo VS Code already installed.
) else (
    echo Downloading VS Code...
    curl -L -o "%TEMP%\vscodesetup.exe" "https://update.code.visualstudio.com/latest/win32-x64-user/stable"
    "%TEMP%\vscodesetup.exe" /VERYSILENT /NORESTART /MERGETASKS=!runcode,addtopath
    del "%TEMP%\vscodesetup.exe"
)

echo Step 3: Installing libraries...
"%PYTHON%" -m pip install --upgrade pip --quiet --user
"%PYTHON%" -m pip install pyinstaller pygame --quiet --user
if errorlevel 1 ( echo ERROR installing libraries & pause & exit /b 1 )

echo Step 4: Writing game files...
"%PYTHON%" "%~dp0write_game.py" "%GAME_DIR%"
if errorlevel 1 ( echo ERROR: write_game.py failed. Is it in the same folder as setup.bat? & pause & exit /b 1 )

echo Step 5: Building EXE (about 1-2 minutes)...
cd /d "%GAME_DIR%"
"%PYTHON%" -m PyInstaller --onefile --windowed --noconfirm --name CatQuiz --icon "%GAME_DIR%\cat_icon.ico" --add-data "%GAME_DIR%\music.mp3;." --add-data "%GAME_DIR%\cat_icon.ico;." --distpath "%GAME_DIR%" --workpath "%TEMP%\pyibuild" --specpath "%TEMP%" cat_quiz.py

if not exist "%GAME_DIR%\CatQuiz.exe" (
    echo ERROR: EXE not created. See errors above.
    pause
    exit /b 1
)

echo Cleaning up...
del /f /q "%GAME_DIR%\cat_quiz.py" >nul 2>&1
del /f /q "%GAME_DIR%\music.mp3" >nul 2>&1
del /f /q "%GAME_DIR%\cat_icon.ico" >nul 2>&1

echo Creating desktop shortcut...
echo Set s=CreateObject("WScript.Shell") > "%TEMP%\s.vbs"
echo Set lnk=s.CreateShortcut(s.SpecialFolders("Desktop") ^& "\Cat Quiz.lnk") >> "%TEMP%\s.vbs"
echo lnk.TargetPath="%GAME_DIR%\CatQuiz.exe" >> "%TEMP%\s.vbs"
echo lnk.WorkingDirectory="%GAME_DIR%" >> "%TEMP%\s.vbs"
echo lnk.Save >> "%TEMP%\s.vbs"
cscript //nologo "%TEMP%\s.vbs"
del "%TEMP%\s.vbs"

echo.
echo DONE! CatQuiz.exe is ready. Shortcut is on your Desktop.
echo.
start "" "%GAME_DIR%"
pause
